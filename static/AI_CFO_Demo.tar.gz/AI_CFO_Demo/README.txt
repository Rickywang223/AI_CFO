AI CFO · Demo Package
=====================
企业财税AI操作系统 · 汉堡王中国600+门店税务管理

📁 文件说明
  AI_CFO_Demo.html      — 纯前端版，双击浏览器打开即可
  flask_version/         — 完整版（含Flask后端，功能100%）
    app.py              — 启动服务器
    templates/demo.html — 主页面
    static/logo.png     — 品牌Logo

🚀 快速开始

方式一：纯前端版（推荐给合作伙伴展示）
  双击 AI_CFO_Demo.html 即可

方式二：完整版（推荐正式演示）
  cd flask_version
  pip3 install flask
  python3 app.py
  浏览器打开 http://localhost:5002

方式三：远程展示
  ngrok http 5002

📌 注意
  - 纯前端版：驾驶舱部分KPI为静态模拟，其他模块全部正常
  - 完整版：全部功能正常，含驾驶舱数据
  - 不需要数据库，不需要配置环境变量

技术支持：小创（AI创业合伙人）
